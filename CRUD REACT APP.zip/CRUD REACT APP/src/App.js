import 'react-bootstrap-icons'
import 'bootstrap/dist/css/bootstrap.min.css';
import 'react-router-dom'
import { BrowserRouter as Router,Switch,Route } from 'react-router-dom/cjs/react-router-dom.min';
import './App.css';
import { useState } from 'react';
import Header from './Components/Header';
import Login from './Components/Login';
import AddUser from './Components/AddUser';
import UserList from './Components/UserList';
import EditUser from './Components/EditUser';
function App() {

  const [userinfo,Setuserinfo]=useState([])
  const adduser=(obj)=>{
    console.log("in adduser"+obj)
    let newarr=[...userinfo,{...obj}]
    Setuserinfo(newarr)
  }
  const deleteuser=(id)=>{
    console.log("in deleteuser"+id)
    let newarr=userinfo.filter((obj)=>obj.fn!==id)
    Setuserinfo(newarr)
  }
  const edituser=(obj)=>{
    let newarr=userinfo.map((user)=>user.fn===obj.fn?obj:user)
    Setuserinfo(newarr)
  }

  const [user,Setuser] =useState("login");
  const loginuser=(obj)=>{
    Setuser(obj);
  }

  return (
    <div>
      <div className='text-danger bg-warning'>
      <Header username={user}></Header>
      </div>
      <div className='border text-primary'>
      <Router >
        <Switch>
          <Route path="/" exact render={(props)=>(<Login userHandller={loginuser}/>)}></Route>
          <Route path="/add" exact render={(props)=>(<AddUser addHandller={adduser}/>)}></Route>
          <Route path="/list" exact render={(props)=>(<UserList arr={userinfo} deleteHandller={deleteuser}/>)}></Route>
          <Route path="/edit" exact render={(props)=>(<EditUser editHandller={edituser}/>)}></Route>
        </Switch>
      </Router>
      </div>
    </div>
  );
}

export default App;

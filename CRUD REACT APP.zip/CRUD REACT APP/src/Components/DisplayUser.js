import { Button } from "react-bootstrap";
import { PenFill, PersonCircle, Trash } from "react-bootstrap-icons";
import { Link } from "react-router-dom/cjs/react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css'
import EditUser from "./EditUser";

const DisplayUser=(props)=>{

  const LOCAL_EDIT_OBJ='edit'
 const trshclick=()=>{
  console.log("in trshdelete !!");
  props.removeHandller(props.data.fn)
 }
 const penclick=()=>{
  console.log("in trshdelete !!");
  localStorage.setItem(LOCAL_EDIT_OBJ,JSON.stringify(props.data))

 }

 

return(
  <div className="container">
    <div className="row">
      <div className="col-md-2">
        <PersonCircle></PersonCircle>
       <span> {props.data.fn}</span>
      </div>
      <div className="col-md-2">
        {props.data.ln}
      </div>
      <div className="col-md-3">
        {props.data.ad}
      </div>
      <div className="col-md-2">
        {props.data.pc}
      </div>
      <div className="col-md-1">
      <Link to={{pathname:'/edit',state:{user:props.data}}}>
     <span> <PenFill onClick={penclick}></PenFill></span>
     </Link>
     </div>
    
     <div className="col-md-2">
    <Trash onClick={trshclick}></Trash>
    </div>
    
    
      </div>
     
  </div>
);

}
export default DisplayUser;
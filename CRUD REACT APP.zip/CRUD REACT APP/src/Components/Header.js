import 'bootstrap/dist/css/bootstrap.min.css'
const Header=(props)=>{



  return(
    <div className='container'>
      <div className='row'>
      <div className='col-md-2'>
    <span>HOME</span>
      </div>
      <div className='col-md-2'>
      <span>ABOUT</span>
</div>
      <div className='col-md-6'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      </div>
      <div className='col-md-2'>
    {props.username}
</div>
      </div>

    </div>
  );
}
export default Header;
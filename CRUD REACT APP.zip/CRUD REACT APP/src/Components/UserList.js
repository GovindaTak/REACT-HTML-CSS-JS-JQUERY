import Table from 'react-bootstrap/Table';
import DisplayUser from './DisplayUser';
import { Button } from "react-bootstrap";
import { PenFill, PersonCircle, Trash } from "react-bootstrap-icons";
import { Link } from "react-router-dom/cjs/react-router-dom";
const UserList=(props)=>{

const  removeUser=(id)=>{
    props.deleteHandller(id);
  }
  // const  editUser=(id)=>{
  //   props.editHandller(id);
  // }

    return(

      <div>
       


   
      {props.arr.map((user,index)=><DisplayUser key={index} data={user}  removeHandller={removeUser}/>)}
     
      <div>
      <div className="bottom">
 <Link to="/add">
  <Button>ADD USER</Button>
  </Link>
  </div>
      </div>

      </div>
    );
}
export default UserList;
{/* <Table striped bordered hover>
<thead>
  <tr>
    <th>#</th>
    <th>First Name</th>
    <th>Last Name</th>
    <th>Address</th>
    <th>Pincode</th>
  </tr>
</thead>
<tbody>  </tbody>
    </Table>*/}



import { Component } from "react";
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import { Link } from "react-router-dom/cjs/react-router-dom";

class AddUser extends Component
{

  constructor(props)
  {
    super();
    this.state={fn:'',ln:'',ad:'',pc:''}
  }
  onclickfun=()=>{
    if(this.state.fn.trim().length===0||this.state.ln.trim().length===0||this.state.ad.trim().length===0||this.state.pc.trim().length===0)
    {
      alert("all fields are required !!");
      return;
    }
    this.props.addHandller(this.state)
    this.setState({fn:'',ln:'',ad:'',pc:''})
  //  this.props.history.push('/list');
  }


  render(){
    return(
     


    <Form>
      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>First Name :</Form.Label>
        <Form.Control type="text" placeholder="Enter first name" value={this.state.fn} onChange={(event)=>this.setState({fn:event.target.value})} />
      
      </Form.Group>
      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Last Name :</Form.Label>
        <Form.Control type="text" placeholder="Enter last name" value={this.state.ln} onChange={(event)=>this.setState({ln:event.target.value})} />
      
      </Form.Group>
      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Address :</Form.Label>
        <Form.Control type="text" placeholder="Enter Address" value={this.state.ad} onChange={(event)=>this.setState({ad:event.target.value})} />
      
      </Form.Group>  <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Pincode :</Form.Label>
        <Form.Control type="text" placeholder="Enter Pincode" value={this.state.pc} onChange={(event)=>this.setState({pc:event.target.value})} />
      
      </Form.Group>
    
     <div onClick={this.onclickfun}>
      <Link to='/list'>
      <Button variant="primary" type="button">
        Register
      </Button>
      </Link>
      </div>
    </Form>




    );
  }


}
export default AddUser;





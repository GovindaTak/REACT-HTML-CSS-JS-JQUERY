import { Component } from "react";
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import { Link } from "react-router-dom/cjs/react-router-dom";

class Login extends Component
{

  constructor(props)
  {
    super(props);
    this.state={name:'',password:''}
  }
  onclickfun=()=>{
    if(this.state.name.trim().length===0||this.state.password.trim().length===0)
    {
      alert("all fields are required !!");
      return;
    }
  //  var str=this.setState({name:})
    this.props.userHandller(this.state.name)
    this.setState({name:'',password:''})
   // this.props.history.push('/add');
  }


  render(){
    return(
     


    <Form>
      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>User Name :</Form.Label>
        <Form.Control type="text" placeholder="Enter user name" value={this.state.name} onChange={(event)=>this.setState({name:event.target.value})} />
        <Form.Text className="text-muted">
          We'll never share your name with anyone else.
        </Form.Text>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicPassword">
        <Form.Label>Password</Form.Label>
        <Form.Control type="password" placeholder="Password"  value={this.state.password} onChange={(event)=>this.setState({password:event.target.value})} />
      </Form.Group>
      
     <div onClick={this.onclickfun}>
      <Link to='/add'>
      <Button variant="primary" type="button">
        Submit
      </Button>
      </Link>
      </div>
    </Form>




    );
  }


}
export default Login;





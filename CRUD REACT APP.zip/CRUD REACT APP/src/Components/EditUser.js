
import { Component } from "react";
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import { Link } from "react-router-dom/cjs/react-router-dom";
import React from "react";
const LOCAL_EDIT_OBJ='edit'
class EditUser extends Component
{
  
  constructor(props)
  {
    console.log("in edit user constructor")
    
    super(props);
    
   var obj=JSON.parse(localStorage.getItem(LOCAL_EDIT_OBJ));
    this.state={fn:obj.fn,ln:obj.ln,ad:obj.ad,pc:obj.pc}
  // this.setState({fn:obj.fn,ln:obj.ln,ad:obj.ad,pc:obj.pc})
  }
  onclickfun=()=>{
    if(this.state.fn.trim().length===0||this.state.ln.trim().length===0||this.state.ad.trim().length===0||this.state.pc.trim().length===0)
    {
      alert("all fields are required !!");
      return;
    }
    this.props.editHandller(this.state)
    this.setState({fn:'',ln:'',ad:'',pc:''})
    
  //  this.props.history.push('/list');
  }


  render(){
    return(
     


    <Form>
      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>First Name :</Form.Label>
        <Form.Control readOnly type="text" placeholder="Enter first name" value={this.state.fn} onChange={(event)=>this.setState({fn:event.target.value})} />
      
      </Form.Group>
      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Last Name :</Form.Label>
        <Form.Control type="text" placeholder="Enter last name" value={this.state.ln} onChange={(event)=>this.setState({ln:event.target.value})} />
      
      </Form.Group>
      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Address :</Form.Label>
        <Form.Control type="text" placeholder="Enter Address" value={this.state.ad} onChange={(event)=>this.setState({ad:event.target.value})} />
      
      </Form.Group>  <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Pincode :</Form.Label>
        <Form.Control type="text" placeholder="Enter Pincode" value={this.state.pc} onChange={(event)=>this.setState({pc:event.target.value})} />
      
      </Form.Group>
    
     <div onClick={this.onclickfun}>
      <Link to='/list'>
      <Button variant="primary" type="button">
        Update
      </Button>
      </Link>
      </div>
    </Form>




    );
  }


}
export default EditUser;




